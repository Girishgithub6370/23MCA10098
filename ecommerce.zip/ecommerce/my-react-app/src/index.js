// src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import PredictionsPage from './App';

ReactDOM.render(
    <React.StrictMode>
        <PredictionsPage />
    </React.StrictMode>,
    document.getElementById('root')
);
