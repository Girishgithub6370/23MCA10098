import express from 'express';
import fetch from 'node-fetch';

const app = express();
const port = 9876;

const windowSize = 10;
const testServerBaseUrl = 'http://20.244.56.144/test/rand';
const qualifiers = ['primes', 'fibonacci', 'even', 'random'];

let numbersQueue = [];

const fetchNumbers = async (qualifier) => {
  if (!qualifiers.includes(qualifier)) {
    throw new Error('Invalid qualifier');
  }

  try {
    const response = await fetch(`${testServerBaseUrl}`, {
      headers: {
        // Add any required headers (e.g., API key, authentication token)
        // 'Authorization': 'Bearer YOUR_API_KEY'
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch ${qualifier} numbers. Status: ${response.status} ${response.statusText}`);
    }
    const data = await response.json();
    return data.numbers || [];
  } catch (error) {
    console.error(`Error fetching ${qualifier} numbers:`, error.message);
    return [];
  }
};


const calculateAverage = (numbers) => {
  const sum = numbers.reduce((acc, num) => acc + num, 0);
  return sum / numbers.length || 0;
};

app.get('/', async (req, res) => {
  try {
    const qualifier = 'random'; // Example qualifier, you can change this as needed
    const fetchedNumbers = await fetchNumbers(qualifier);
    console.log('Fetched Numbers in Root:', fetchedNumbers); // Log fetched numbers
    res.send(`Fetched Numbers in Root: ${fetchedNumbers.join(', ')}`);
  } catch (error) {
    console.error('Error processing request:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/numbers/:qualifier', async (req, res) => {
  try {
    const qualifier = req.params.qualifier.toLowerCase();
    const fetchedNumbers = await fetchNumbers(qualifier);
    console.log('Fetched Numbers:', fetchedNumbers); // Log fetched numbers
    numbersQueue = Array.from(new Set([...numbersQueue, ...fetchedNumbers])).slice(-windowSize);
    const avg = calculateAverage(numbersQueue);
    const response = {
      fetchedNumbers: fetchedNumbers,
      windowPrevState: numbersQueue.slice(0, -fetchedNumbers.length),
      windowCurrState: numbersQueue,
      avg: avg.toFixed(2),
    };
    console.log('Response:', response); // Log the response object
    res.json(response);
  } catch (error) {
    console.error('Error processing request:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
