// src/App.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PredictionsPage = () => {
    const [predictions, setPredictions] = useState([]);

    useEffect(() => {
        const fetchPredictions = async () => {
            try {
                const response = await axios.get('http://20.244.56.144/test/companies/AMZ/categories/Laptop/products?top=10&minPrice=1&maxPrice=10000');
                setPredictions(response.data.message);
            } catch (error) {
                console.error('Error fetching predictions:', error);
            }
        };

        fetchPredictions();
    }, []);

    return (
        <div>
            <h1>Nationality Predictions</h1>
            <ul>
                {predictions.map((prediction, index) => (
                    <li key={index}>
                        <p>company: {prediction.message}</p>
                        {/* <p>owner: {prediction.ownername}</p> */}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default PredictionsPage;
